"""
Version information for the metapop package.
"""

__all__ = ["__version__", "__versiondate__"]

__version__ = "0.4.6"
__versiondate__ = "2025-05-28"
